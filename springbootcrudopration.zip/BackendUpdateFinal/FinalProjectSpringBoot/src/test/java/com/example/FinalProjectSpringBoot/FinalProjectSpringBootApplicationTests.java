package com.example.FinalProjectSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
